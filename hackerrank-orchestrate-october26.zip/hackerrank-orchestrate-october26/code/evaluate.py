#!/usr/bin/env python3
from evaluation.main import main

if __name__ == "__main__":
    raise SystemExit(main())
